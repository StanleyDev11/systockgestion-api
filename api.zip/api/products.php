<?php
require_once 'db.php';
require_once 'auth_helpers.php'; // Inclure le nouveau fichier d'aide

header('Content-Type: application/json');

$conn = getDbConnection();
$method = $_SERVER['REQUEST_METHOD'];

// La méthode GET reste publique
if ($method == 'GET') {
    handleGet($conn);
    $conn->close();
    exit();
}

// Pour POST, PUT, DELETE, une authentification est requise
$user = verifyToken($conn);
if (!$user) {
    http_response_code(401);
    echo json_encode(['message' => 'Unauthorized: Invalid or expired token']);
    $conn->close();
    exit();
}

// Un simple routeur basé sur la méthode HTTP
switch ($method) {
    case 'POST':
        handlePost($conn, $user);
        break;
    case 'PUT':
        handlePut($conn, $user);
        break;
    case 'DELETE':
        handleDelete($conn, $user);
        break;
    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['message' => 'Method not supported']);
        break;
}

$conn->close();

// --- Fonctions de gestion pour chaque méthode ---

function handleGet($conn) {
    if (isset($_GET['id'])) {
        // Récupérer un seul produit
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($product = $result->fetch_assoc()) {
            echo json_encode($product);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Product not found']);
        }
        $stmt->close();
    } else {
        // Récupérer tous les produits
        $result = $conn->query("SELECT * FROM products ORDER BY name ASC");
        $products = [];
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        echo json_encode($products);
    }
}

function handlePost($conn, $user) {
    // Tous les utilisateurs connectés peuvent créer un produit
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['name']) || !isset($data['quantity']) || !isset($data['price'])) {
        http_response_code(400); // Bad Request
        echo json_encode(['message' => 'Missing required fields: name, quantity, price']);
        return;
    }

    $name = $data['name'];
    $description = $data['description'] ?? '';
    $quantity = intval($data['quantity']);
    $price = floatval($data['price']);

    $stmt = $conn->prepare("INSERT INTO products (name, description, quantity, price) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $name, $description, $quantity, $price);
    
    if ($stmt->execute()) {
        http_response_code(201); // Created
        $newId = $conn->insert_id;
        echo json_encode(['id' => $newId, 'name' => $name, 'description' => $description, 'quantity' => $quantity, 'price' => $price]);
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to create product', 'error' => $stmt->error]);
    }
    $stmt->close();
}

function handlePut($conn, $user) {
    // Seuls Admin et Manager peuvent modifier
    if ($user['role'] !== 'Admin' && $user['role'] !== 'Manager') {
        http_response_code(403); // Forbidden
        echo json_encode(['message' => 'Forbidden: You do not have permission to perform this action']);
        return;
    }

    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Product ID is required']);
        return;
    }
    $id = intval($_GET['id']);
    $data = json_decode(file_get_contents('php://input'), true);

    // Vérifier si le produit existe
    $stmt_check = $conn->prepare("SELECT id FROM products WHERE id = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    if ($result_check->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['message' => 'Product not found']);
        $stmt_check->close();
        return;
    }
    $stmt_check->close();

    $name = $data['name'];
    $description = $data['description'] ?? '';
    $quantity = intval($data['quantity']);
    $price = floatval($data['price']);

    $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, quantity = ?, price = ? WHERE id = ?");
    $stmt->bind_param("ssidi", $name, $description, $quantity, $price, $id);

    if ($stmt->execute()) {
        echo json_encode(['message' => 'Product updated successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to update product', 'error' => $stmt->error]);
    }
    $stmt->close();
}

function handleDelete($conn, $user) {
    // Seul l'Admin peut supprimer
    if ($user['role'] !== 'Admin') {
        http_response_code(403); // Forbidden
        echo json_encode(['message' => 'Forbidden: You do not have permission to perform this action']);
        return;
    }

    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Product ID is required']);
        return;
    }
    $id = intval($_GET['id']);

    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Product deleted successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Product not found']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to delete product', 'error' => $stmt->error]);
    }
    $stmt->close();
}
?>

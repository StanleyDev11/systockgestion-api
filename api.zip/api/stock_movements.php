<?php
require_once 'db.php';
require_once 'auth_helpers.php'; // Inclure le nouveau fichier d'aide

header('Content-Type: application/json');

$conn = getDbConnection();

// Pour toutes les méthodes (GET, POST), une authentification est requise
$user = verifyToken($conn);
if (!$user) {
    http_response_code(401);
    echo json_encode(['message' => 'Unauthorized: Invalid or expired token']);
    $conn->close();
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet($conn, $user);
        break;
    case 'POST':
        handlePost($conn, $user);
        break;
    default:
        http_response_code(405); // Method Not Allowed
        echo json_encode(['message' => 'Method not supported for stock movements']);
        break;
}

$conn->close();

function handleGet($conn, $user) {
    // Récupérer l'historique des mouvements, en joignant le nom du produit
    $sql = "SELECT sm.id, sm.product_id, p.name as product_name, sm.movement_type, sm.quantity, sm.date 
            FROM stock_movements sm
            JOIN products p ON sm.product_id = p.id
            ORDER BY sm.date DESC";
    
    $result = $conn->query($sql);
    
    if ($result) {
        $movements = [];
        while ($row = $result->fetch_assoc()) {
            $movements[] = $row;
        }
        echo json_encode($movements);
    } else {
        http_response_code(500);
        echo json_encode(['message' => 'Failed to retrieve stock movements', 'error' => $conn->error]);
    }
}

function handlePost($conn, $user) {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['product_id'], $data['movement_type'], $data['quantity'])) {
        http_response_code(400);
        echo json_encode(['message' => 'Missing required fields: product_id, movement_type, quantity']);
        return;
    }

    $productId = intval($data['product_id']);
    $movementType = $data['movement_type'];
    $quantity = intval($data['quantity']);

    if (!in_array($movementType, ['IN', 'OUT'])) {
        http_response_code(400);
        echo json_encode(['message' => "Invalid movement_type. Must be 'IN' or 'OUT'"]);
        return;
    }
    if ($quantity <= 0) {
        http_response_code(400);
        echo json_encode(['message' => 'Quantity must be positive']);
        return;
    }

    // Démarrer une transaction pour garantir l'intégrité des données
    $conn->begin_transaction();

    try {
        // 1. Récupérer la quantité actuelle et verrouiller la ligne pour la mise à jour
        $stmt = $conn->prepare("SELECT quantity FROM products WHERE id = ? FOR UPDATE");
        $stmt->bind_param("i", $productId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            throw new Exception('Product not found', 404);
        }
        $currentQuantity = $result->fetch_assoc()['quantity'];
        $stmt->close();

        // 2. Calculer la nouvelle quantité et vérifier le stock si c'est une sortie
        $newQuantity = $currentQuantity;
        if ($movementType == 'IN') {
            $newQuantity += $quantity;
        } else { // 'OUT'
            if ($currentQuantity < $quantity) {
                throw new Exception('Insufficient stock', 409); // 409 Conflict
            }
            $newQuantity -= $quantity;
        }

        // 3. Mettre à jour la quantité du produit
        $stmt = $conn->prepare("UPDATE products SET quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $newQuantity, $productId);
        if (!$stmt->execute()) {
            throw new Exception('Failed to update product quantity: ' . $stmt->error, 500);
        }
        $stmt->close();

        // 4. Insérer le mouvement de stock
        // Pourrait être étendu pour logger quel utilisateur a fait le mouvement: $user['id']
        $stmt = $conn->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $productId, $movementType, $quantity);
        if (!$stmt->execute()) {
            throw new Exception('Failed to record stock movement: ' . $stmt->error, 500);
        }
        $stmt->close();

        // Si tout s'est bien passé, valider la transaction
        $conn->commit();
        http_response_code(201);
        echo json_encode(['message' => 'Stock movement recorded successfully', 'new_quantity' => $newQuantity]);

    } catch (Exception $e) {
        // En cas d'erreur, annuler la transaction
        $conn->rollback();
        $errorCode = $e->getCode() >= 400 ? $e->getCode() : 500;
        http_response_code($errorCode);
        echo json_encode(['message' => $e->getMessage()]);
    }
}
?>

<?php
// Permet les requêtes cross-origin (utile pour le développement local avec Flutter)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Le navigateur envoie une requête OPTIONS (preflight) avant les requêtes cross-origin complexes (PUT, DELETE, etc.)
// Il faut y répondre avec un statut 200 OK pour que la vraie requête soit envoyée.
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// --- Remplacer par vos informations de base de données ---
define('DB_HOST', 'sql311.infinityfree.com');
define('DB_USER', 'if0_40395420');
define('DB_PASS', 'R5GCHz1RoQ4Pdx');
define('DB_NAME', 'if0_40395420_stock_management');
// ---------------------------------------------------------

/**
 * Crée et retourne une connexion à la base de données.
 * En cas d'échec, un message d'erreur JSON est retourné et le script s'arrête.
 * @return mysqli
 */
function getDbConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    // Vérifier la connexion
    if ($conn->connect_error) {
        header('Content-Type: application/json');
        http_response_code(500); // Erreur interne du serveur
        echo json_encode([
            'status' => 'error',
            'message' => 'Database connection failed: ' . $conn->connect_error
        ]);
        exit(); // Arrêter le script en cas d'échec de la connexion
    }

    // S'assurer que la communication est en UTF-8
    $conn->set_charset("utf8");

    return $conn;
}
?>
